from django.apps import AppConfig


class JoyConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'joy'
