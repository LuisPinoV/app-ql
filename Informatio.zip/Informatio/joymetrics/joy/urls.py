from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('', views.Inicio, name = 'Inicio'),
    path('grafico/', views.graficos_view, name = 'graficos'),
    path('grafico2/', views.Grafico2, name = 'grafico2'),
]